module.exports.endpoints = require('./endpoints');
