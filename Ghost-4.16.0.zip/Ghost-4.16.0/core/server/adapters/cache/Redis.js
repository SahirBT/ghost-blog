/* eslint-disable ghost/filenames/match-regex */
const RedisCache = require('@tryghost/adapter-cache-redis');

module.exports = RedisCache;
