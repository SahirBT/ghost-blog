const CardAssetService = require('./CardAssetService');
let cardAssetService = new CardAssetService();

module.exports = cardAssetService;
