const CommentCountsAssetsService = require('./CommentCountsAssetsService');
let commentCountsAssets = new CommentCountsAssetsService();

module.exports = commentCountsAssets;
