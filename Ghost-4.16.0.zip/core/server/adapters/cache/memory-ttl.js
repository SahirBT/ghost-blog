const TTLMemoryCache = require('@tryghost/adapter-cache-memory-ttl');

module.exports = TTLMemoryCache;
