module.exports = {
    bulkEdit(data, apiConfig, frame) {
        frame.response = data;
    }
};
