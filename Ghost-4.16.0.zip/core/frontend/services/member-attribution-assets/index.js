const MemberAttributionAssetsService = require('./MemberAttributionAssetsService');
const memberAttributionAssets = new MemberAttributionAssetsService();

module.exports = memberAttributionAssets;
