module.exports = {
    checks: require('./checks'),
    entryLookup: require('./entry-lookup'),
    fetchData: require('./fetch-data')
};
